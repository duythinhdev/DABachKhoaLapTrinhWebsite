import React from 'react';

function Notfoundpage() {
    return (
        <div>
            404 not found
        </div>
    );
}

export default Notfoundpage;
