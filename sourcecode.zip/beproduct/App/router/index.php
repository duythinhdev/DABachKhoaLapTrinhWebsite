<?php

include_once PATH_ROOT . '/App/router/product/routes.php';
include_once PATH_ROOT . '/App/router/user/UserRoutes.php';
include_once PATH_ROOT . '/App/router/news/NewsRoutes.php';
include_once PATH_ROOT . '/App/router/comment/CommentRoutes.php';
include_once PATH_ROOT . '/App/router/order/OrderRoutes.php';
include_once PATH_ROOT . '/App/router/review/ReviewRoutes.php';
include_once PATH_ROOT . '/App/router/option/option.php';
include_once PATH_ROOT . '/App/router/order_option/order_option.php';
include_once PATH_ROOT . '/App/router/Category/CategoryRoutes.php';

?>