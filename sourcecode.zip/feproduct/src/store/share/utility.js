export const updateObject = (oldobject,newobject) => {
    return {
        ...oldobject,
        ...newobject
    }
}
