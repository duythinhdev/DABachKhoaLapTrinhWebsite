import React from 'react';

interface props{
    data:boolean,

}
const ModalBuyProduct = () =>  {
    return (
        <div>

        </div>
    );
}

export default ModalBuyProduct;
