<?php
interface ModelInterFace {
    public function get();
    public function getDetail();
    public function create();
    public function delete();
    public function update();
}

?>