export const enviroment = {
    local: "http://localhost:99/DoAnLapTrinhWeb/beproduct/",
    locals: "http://localhost/DABachKhoaLapTrinhWebsite/beproduct/"
}
