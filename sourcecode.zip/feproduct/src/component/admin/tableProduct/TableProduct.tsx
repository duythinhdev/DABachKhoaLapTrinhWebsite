import * as React from 'react';
import "./tableProduct.scss";
import {useEffect, useState, useLayoutEffect} from "react";
import axios, {AxiosResponse} from "axios";
import {makeStyles, createMuiTheme} from '@material-ui/core/styles';
import {
    TableRow,
    TableHead,
    TableContainer,
    TableCell,
    TableBody,
    Table,
    Paper,
    TablePagination,
} from '@mui/material';
import ModalAddProduct from "./modalAddProduct/modalAddProduct";
import {columnsNamesTableProducts} from "../NameColumsTable/NameColumnsTable";
import ModalUpdateProduct from "../tableProduct/ModalUpdateProduct/ModalUpdateProduct";
import { enviroment } from "../../../enviroment/enviroment";


const theme = createMuiTheme({
    spacing: 4,
});

const useStyles = makeStyles({
    root: {
        background: '#FAF3EC',
        width: 'auto',
        position: 'absolute',
        top: 'calc(50% - 240px)',
        left: 'calc(40% - 160px)',
    },
    formImage: {
        boxShadow: '0 0 10px',
        backgroundColor: 'white',
        width: '500px',
        height: '500px',
        display: 'flex',
        flexWrap: 'wrap',
    },
    textField: {
        marginLeft: theme.spacing(1),
        marginRight: theme.spacing(1),
        width: '25ch',
    },
    divForm: {
        width: '90%',
    },
    image: {
        width: "90%",
        height: "35%",
        margin: "8px"
    },
    paperRoot: {
        maxWidth: 345,
    }

});
const TableProduct = () => {

    const [state, setState] = useState({
        dataPagination: [] as any,
        totalpage: 1 as any,
        file: '' as any,
        DataModalUpdate: [] as any,
    });


    const [modalUpdate,setModalUpdate] = useState(false) as any;
    const [dataModalUpdate,setDataModalUpdate] = useState([]) as any;
    const [page,setPage ] = useState(1) as any;
    const [rowsPerPage,setRowPerPage] = useState(10) as any;
    let fetchDataProduct = async () => {
        let apiPagination = `v1/product/get?pagenumber=${page}&pagesize=${rowsPerPage}`;
        await axios.get(enviroment.local + apiPagination)
            .then((res: AxiosResponse<any>) => {
                setState({...state, totalpage: res.data.response.totalpage[0].total})
                setState({...state, dataPagination: res.data.response.data});
            }).catch(err => console.log(err));
        console.log("123",state.dataPagination);
    }
    useLayoutEffect(() => {
        fetchDataProduct();
    }, [])
    const handleChangePage = async (event: any, newPage: any) => {
        setPage(newPage);
        fetchDataProduct();
    };

    const handleChangeRowsPerPage =  (event: any) => {
        console.log("event.target.value",event.target.value)
        setRowPerPage(+event.target.value);
        setPage(0);
    }


    const updateData = async (id: any) => {
        let apiGetDetail = `v1/product/getdetail?id=${id}`;
        await axios.get(enviroment.local + apiGetDetail)
            .then((res: AxiosResponse<any>) => {
                setDataModalUpdate(res.data.response.data)
            }).catch(err => console.log(err));
        await setModalUpdate(true);
    }
    const closeUpdateData = () => {
        setModalUpdate(false)
    }
    const classes = useStyles();
    return (
        <div className="TableProduct">
            <Paper sx={{width: '85%'}}>
                <TableContainer sx={{maxHeight: 440}}>
                    <Table stickyHeader aria-label="sticky table">
                        <TableHead>
                            <TableRow>
                                <TableCell align="center" colSpan={12}>
                                    <h3>Control Product</h3>
                                </TableCell>
                            </TableRow>
                            <ModalAddProduct fetchDataProduct={fetchDataProduct} />
                            <TableRow>
                                {columnsNamesTableProducts.map((column: any) => (
                                    <TableCell
                                        key={column.id}
                                        align={column.align}
                                        style={{top: 57, minWidth: column.minWidth}}
                                    >
                                        {column.label}
                                    </TableCell>
                                ))}
                            </TableRow>
                        </TableHead>
                        <TableBody>
                            {
                                state.dataPagination?.map((res: any, index: number) => {
                                  return  <TableRow hover role="checkbox" tabIndex={-1} key={index}>
                                        <TableCell align={res.align} onClick={() => updateData(res.id)}>
                                            {res.id}
                                        </TableCell>
                                        <TableCell align={res.align} onClick={() => updateData(res.id)}>
                                            {res.Product_name}
                                        </TableCell>
                                        <TableCell align={res.align} onClick={() => updateData(res.id)}>
                                            <img src={enviroment.local + '/' + res.image}  width="500" height="400"  />
                                        </TableCell>
                                        <TableCell align={res.align} onClick={() => updateData(res.id)}>
                                            {res.description}
                                        </TableCell>
                                        <TableCell align={res.align} onClick={() => updateData(res.id)}>
                                            {res.created_at}
                                        </TableCell>
                                        <TableCell align={res.align} onClick={() => updateData(res.id)}>
                                            {res.updated_at}
                                        </TableCell>
                                        <TableCell key={index} align={res.align}>
                                            {res.id_catergory_product}
                                        </TableCell>
                                    </TableRow>
                                })
                            }
                        </TableBody>
                    </Table>
                </TableContainer>
                <TablePagination
                    rowsPerPageOptions={[1, 10, 25, 100]}
                    component="div"
                    count={state.totalpage}
                    rowsPerPage={rowsPerPage}
                    page={page}
                    onPageChange={handleChangePage}
                    onRowsPerPageChange={handleChangeRowsPerPage}
                />
                {
                    modalUpdate && <ModalUpdateProduct dataModalUpdate={dataModalUpdate}
                                                       modalUpdate={modalUpdate}
                                                       closeUpdateDatas={closeUpdateData}
                                                       fetchDataProduct={fetchDataProduct}
                    />
                }
            </Paper>
        </div>
    );
}
export default TableProduct;
